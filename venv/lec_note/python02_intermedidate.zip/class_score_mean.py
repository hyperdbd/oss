from mean_var import mean_var

try:
    with open('data/class_score_kr.csv', 'r') as fi, \
         open('class_score_mean.csv', 'w') as fo:
        for line in fi.readlines():
            try:
                values = [int(text) for text in line.split(',')]
                mean, var = mean_var(values)
                for val in values:
                    fo.write(f'{val}, ')
                fo.write(f'{mean}, {var}\n')

            except ValueError as ex:
                print(f'A line is ignored. (message: {ex})')
        print('The program was terminated successfully.')
except Exception as ex:
    print(f'Cannot run the program. (message: {ex})')